package com.project.account.service;

import com.project.account.bean.DetailsOfUser;
import com.project.account.exception.AccountException;

public interface IAccountBasicService {

	
	int addAccDao(DetailsOfUser a);
	double depositDao(double money);
	double withdrawDao(double money) ;
	double showBalDao();
	boolean checkLogin(int accNo) throws AccountException;
	boolean checkPassword(String pwd);
	String currentUser();
	boolean transferAmt(int toAccNo, double money) throws AccountException;
	void printTransdetails();
}
