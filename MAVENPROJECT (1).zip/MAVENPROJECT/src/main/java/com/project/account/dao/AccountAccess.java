package com.project.account.dao;

import java.util.TreeMap;

import com.project.account.bean.DetailsOfUser;
import com.project.account.exception.AccountException;

public class AccountAccess implements IAccountAccess {
	
	TreeMap<Integer, DetailsOfUser> map = new TreeMap<Integer, DetailsOfUser>();
	
	public int accCreation(DetailsOfUser a) {
		a.setAccNum();
		map.put(a.getAccNum(), a);
		return a.getAccNum();
	}

	public DetailsOfUser loginUser(int accNo) throws AccountException {
		DetailsOfUser temp = new DetailsOfUser();
		
		try {
			temp = map.get(accNo);
			return temp;
				
		}
		catch(NullPointerException e) {
			if(temp==null)
			throw new AccountException("There is no such Account");
		}
		return null;
	}

	public void updateDetails(int accNo, DetailsOfUser a) {
		map.replace(accNo, a);
		
	}

}
