package com.project.account.dao;

import com.project.account.bean.DetailsOfUser;
import com.project.account.exception.AccountException;

public interface IAccountAccess {
	
	int accCreation(DetailsOfUser a);
	
	DetailsOfUser loginUser(int accNo) throws AccountException;
	
	void updateDetails(int accNo, DetailsOfUser a);

}
